#ifndef HV_CONTRIB_H
#define HV_CONTRIB_H

double *
hv_contrib (const double *points, int dim, int size, const double * ref,
            const bool * uev);

#endif 
